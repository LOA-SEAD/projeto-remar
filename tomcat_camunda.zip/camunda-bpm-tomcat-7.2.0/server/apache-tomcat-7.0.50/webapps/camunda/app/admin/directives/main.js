ngDefine('admin.directives', [
	
], function(module) {

});