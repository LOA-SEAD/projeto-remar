ngDefine('admin.filters', [
	
], function(module) {

});