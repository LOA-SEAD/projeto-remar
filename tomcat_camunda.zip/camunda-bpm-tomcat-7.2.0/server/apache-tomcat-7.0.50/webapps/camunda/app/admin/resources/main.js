ngDefine('admin.resources', [
	'./userResource',
	'./groupResource',
	'./groupMembershipResource',
	'./initialUserResource'
], function(module) {

});
