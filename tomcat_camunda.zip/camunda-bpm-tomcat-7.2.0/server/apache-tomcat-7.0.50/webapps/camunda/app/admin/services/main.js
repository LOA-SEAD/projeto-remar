ngDefine('admin.services', [
	
], function(module) {

});