ngDefine('cockpit.plugin.base.data', [
  // dashboard
  './dashboard/processDefinitionStatisticsData',
  
  // process definition
  './processDefinition/activityInstanceStatisticsData',
], function(module) {

});
