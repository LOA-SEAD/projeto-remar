ngDefine('cockpit.plugin.base.resources', [
  './processDefinition',
  './processInstance'
], function(module) {

});
