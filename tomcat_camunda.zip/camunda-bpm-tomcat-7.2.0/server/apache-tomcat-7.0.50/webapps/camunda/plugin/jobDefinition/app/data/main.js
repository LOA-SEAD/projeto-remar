ngDefine('cockpit.plugin.jobDefinition.data', [
  './processDefinition/jobDefinitionData'
], function(module) {

});