ngDefine('cockpit.plugin.jobDefinition', [
  'module:cockpit.plugin.jobDefinition.views:./views/main',
  'module:cockpit.plugin.jobDefinition.data:./data/main'
], function(module) {
  return module;
});
