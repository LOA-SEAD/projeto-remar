ngDefine('cockpit.plugin.jobDefinition.views', [
  './processDefinition/jobDefinitionTable',
  './processDefinition/jobDefinitionSuspensionState',
  './processDefinition/jobDefinitionSuspensionOverlay',
  './processDefinition/suspensionStateAction'
], function(module) {

});